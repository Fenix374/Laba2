﻿namespace Laba1
{


    partial class ASSASINS_CREEDDataSet
    {
        partial class CHARACTERSDataTable
        {
        }
    }
}

namespace Laba1.ASSASINS_CREEDDataSetTableAdapters {
    
    
    public partial class CHARACTERSTableAdapter {
    }
}
