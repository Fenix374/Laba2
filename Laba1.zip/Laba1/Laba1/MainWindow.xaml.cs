﻿using Laba1.ASSASINS_CREEDDataSetTableAdapters;
using Laba1;
using System;
using System.Windows;
using System.Windows.Controls;

namespace ASSASINS_CREED
{
    public partial class MainWindow : Window
    {

        private ASSASINS_CREEDDataSet dataSet;
        private GAMESTableAdapter gamesAdapter;

        public MainWindow()
        {
            InitializeComponent();

            dataSet = new ASSASINS_CREEDDataSet();
            gamesAdapter = new GAMESTableAdapter();

            gamesAdapter.Fill(dataSet.GAMES);

            dataGrid.ItemsSource = dataSet.GAMES.DefaultView;
        }
    }
}
